package com.example.cs360projectracheltrainor;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    // Display current and goal weight
    private TextView currentWeightDisplay;
    private TextView goalWeightDisplay;
    private Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Get instance of database
        db = Database.getInstance(this);

        // Connect UI elements to layout
        currentWeightDisplay =
                findViewById(R.id.currentWeightDisplay);

        goalWeightDisplay =
                findViewById(R.id.goalWeightDisplay);

        // Button for SMS permissions screen
        Button buttonPermissions =
                findViewById(R.id.buttonPermissions);

        // Button for weight log screen
        Button buttonWeightLog =
                findViewById(R.id.buttonWeightLog);

        // Button for progress screen
        Button buttonProgress =
                findViewById(R.id.buttonProgress);

        // Logout button
        Button logout =
                findViewById(R.id.buttonLogout);

        // Transition animation for SMS permissions screen
        buttonPermissions.setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    Activity_sms.class
            );

            ActivityOptions options =
                    ActivityOptions.makeCustomAnimation(
                            HomeActivity.this,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out
                    );

            startActivity(
                    intent,
                    options.toBundle()
            );
        });

        // Transition animation for weight log screen
        buttonWeightLog.setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    WeightActivity.class
            );

            ActivityOptions options =
                    ActivityOptions.makeCustomAnimation(
                            HomeActivity.this,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out
                    );

            startActivity(
                    intent,
                    options.toBundle()
            );
        });

        // Transition animation for progress screen
        buttonProgress.setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    ProgressActivity.class
            );

            ActivityOptions options =
                    ActivityOptions.makeCustomAnimation(
                            HomeActivity.this,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out
                    );

            startActivity(
                    intent,
                    options.toBundle()
            );
        });

        // Handle logout by navigating to login screen
        logout.setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    LoginActivity.class
            );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Get latest values when Home screen opens
        double goal = db.getGoalWeight();
        double current = db.getLatestWeight();

        // Update UI with current weight
        currentWeightDisplay.setText(
                "Current Weight: " +
                        (current > 0 ? current : "N/A")
        );

        // Update UI with goal weight
        goalWeightDisplay.setText(
                "Goal Weight: " +
                        (goal > 0 ? goal : "Not Set")
        );
    }
}