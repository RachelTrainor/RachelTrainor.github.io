package com.example.cs360projectracheltrainor;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Locale;

public class ProgressActivity extends AppCompatActivity {

    private Database db;

    private TextView startingWeightDisplay;
    private TextView currentWeightDisplay;
    private TextView totalChangeDisplay;
    private TextView averageChangeDisplay;
    private TextView recentChangeDisplay;
    private TextView recentTrendDisplay;
    private TextView goalWeightDisplay;
    private TextView goalProgressDisplay;

    private ProgressBar goalProgressBar;

    private static final DateTimeFormatter[] DATE_FORMATS = {
            DateTimeFormatter.ofPattern("M/d/yyyy"),
            DateTimeFormatter.ofPattern("M/d/yy"),
            DateTimeFormatter.ofPattern("M-d-yyyy"),
            DateTimeFormatter.ofPattern("M-d-yy"),
            DateTimeFormatter.ISO_LOCAL_DATE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);

        db = Database.getInstance(this);

        initializeViews();
        displayProgress();
    }

    /*
     * Connect the progress fields to the layout.
     */
    private void initializeViews() {

        startingWeightDisplay =
                findViewById(R.id.startingWeightDisplay);

        currentWeightDisplay =
                findViewById(R.id.progressCurrentWeightDisplay);

        totalChangeDisplay =
                findViewById(R.id.totalChangeDisplay);

        averageChangeDisplay =
                findViewById(R.id.averageChangeDisplay);

        recentChangeDisplay =
                findViewById(R.id.recentChangeDisplay);

        recentTrendDisplay =
                findViewById(R.id.recentTrendDisplay);

        goalWeightDisplay =
                findViewById(R.id.progressGoalWeightDisplay);

        goalProgressDisplay =
                findViewById(R.id.goalProgressDisplay);

        goalProgressBar =
                findViewById(R.id.goalProgressBar);

        Button homeButton =
                findViewById(R.id.buttonProgressHome);

        homeButton.setOnClickListener(v -> finish());
    }

    /*
     * Retrieve weight records, store them in an ArrayList,
     * sort them by date, and calculate progress.
     */
    private void displayProgress() {

        ArrayList<WeightRecord> records =
                new ArrayList<>();

        Cursor cursor = db.getAllWeights();

        if (cursor.moveToFirst()) {

            do {

                long id = cursor.getLong(
                        cursor.getColumnIndexOrThrow(
                                Database.W_ID
                        )
                );

                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                Database.W_DATE
                        )
                );

                double weight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow(
                                Database.W_WEIGHT
                        )
                );

                records.add(
                        new WeightRecord(
                                id,
                                date,
                                weight
                        )
                );

            } while (cursor.moveToNext());
        }

        cursor.close();

        /*
         * Sort the ArrayList from oldest to newest.
         * This makes the first and last records
         * represent the starting and current weights.
         */
        records.sort(
                Comparator.comparing(
                        record ->
                                parseDate(
                                        record.getDate()
                                )
                )
        );

        if (records.isEmpty()) {

            showNoData();
            return;
        }

        double startingWeight =
                records.get(0).getWeight();

        double currentWeight =
                records.get(
                        records.size() - 1
                ).getWeight();

        double totalChange =
                currentWeight - startingWeight;

        double goalWeight =
                db.getGoalWeight();

        startingWeightDisplay.setText(
                String.format(
                        Locale.US,
                        "Starting Weight: %.1f lbs",
                        startingWeight
                )
        );

        currentWeightDisplay.setText(
                String.format(
                        Locale.US,
                        "Current Weight: %.1f lbs",
                        currentWeight
                )
        );

        /*
         * Display total weight lost or gained.
         */
        if (totalChange < 0) {

            totalChangeDisplay.setText(
                    String.format(
                            Locale.US,
                            "Total Lost: %.1f lbs",
                            Math.abs(totalChange)
                    )
            );

        } else if (totalChange > 0) {

            totalChangeDisplay.setText(
                    String.format(
                            Locale.US,
                            "Total Gained: %.1f lbs",
                            totalChange
                    )
            );

        } else {

            totalChangeDisplay.setText(
                    "Total Change: 0.0 lbs"
            );
        }

        /*
         * At least two records are required for
         * average change, recent change, and trend.
         */
        if (records.size() > 1) {

            double averageChange =
                    calculateAverageChange(records);

            averageChangeDisplay.setText(
                    String.format(
                            Locale.US,
                            "Average Change Per Entry: %+.1f lbs",
                            averageChange
                    )
            );

            displayRecentChange(records);

            recentTrendDisplay.setText(
                    "Recent Trend: " +
                            calculateRecentTrend(records)
            );

        } else {

            averageChangeDisplay.setText(
                    "Average Change Per Entry: Not enough data"
            );

            recentChangeDisplay.setText(
                    "Recent Change: Not enough data"
            );

            recentTrendDisplay.setText(
                    "Recent Trend: Not enough data"
            );
        }

        /*
         * Calculate and display goal progress.
         */
        if (goalWeight > 0) {

            goalWeightDisplay.setText(
                    String.format(
                            Locale.US,
                            "Goal Weight: %.1f lbs",
                            goalWeight
                    )
            );

            double progress =
                    calculateGoalProgress(
                            startingWeight,
                            currentWeight,
                            goalWeight
                    );

            goalProgressDisplay.setText(
                    String.format(
                            Locale.US,
                            "Goal Progress: %.1f%%",
                            progress
                    )
            );

            /*
             * The ProgressBar uses an integer from
             * 0 to 100, so round the calculated
             * percentage before displaying it.
             */
            goalProgressBar.setProgress(
                    (int) Math.round(progress)
            );

        } else {

            goalWeightDisplay.setText(
                    "Goal Weight: Not Set"
            );

            goalProgressDisplay.setText(
                    "Goal Progress: Set a goal to calculate progress"
            );

            goalProgressBar.setProgress(0);
        }
    }

    /*
     * Compare the two newest chronological records.
     */
    private void displayRecentChange(
            ArrayList<WeightRecord> records
    ) {

        double previousWeight =
                records.get(
                        records.size() - 2
                ).getWeight();

        double newestWeight =
                records.get(
                        records.size() - 1
                ).getWeight();

        double recentChange =
                newestWeight - previousWeight;

        if (recentChange < 0) {

            recentChangeDisplay.setText(
                    String.format(
                            Locale.US,
                            "Recent Change: %.1f lbs lost",
                            Math.abs(recentChange)
                    )
            );

        } else if (recentChange > 0) {

            recentChangeDisplay.setText(
                    String.format(
                            Locale.US,
                            "Recent Change: %.1f lbs gained",
                            recentChange
                    )
            );

        } else {

            recentChangeDisplay.setText(
                    "Recent Change: No change"
            );
        }
    }

    /*
     * Convert stored dates into LocalDate values
     * so they can be sorted correctly.
     */
    private LocalDate parseDate(String date) {

        for (DateTimeFormatter formatter :
                DATE_FORMATS) {

            try {

                return LocalDate.parse(
                        date,
                        formatter
                );

            } catch (
                    DateTimeParseException ignored
            ) {

                // Try the next supported format.
            }
        }

        return LocalDate.MAX;
    }

    /*
     * Calculate the average change between
     * consecutive weight entries.
     */
    private double calculateAverageChange(
            ArrayList<WeightRecord> records
    ) {

        double totalChange = 0.0;

        for (int i = 1;
             i < records.size();
             i++) {

            totalChange +=
                    records.get(i).getWeight()
                            -
                            records.get(i - 1).getWeight();
        }

        return totalChange /
                (records.size() - 1);
    }

    /*
     * Analyze up to the three most recent records.
     */
    private String calculateRecentTrend(
            ArrayList<WeightRecord> records
    ) {

        int startIndex =
                Math.max(
                        0,
                        records.size() - 3
                );

        double trendChange = 0.0;

        for (int i = startIndex + 1;
             i < records.size();
             i++) {

            trendChange +=
                    records.get(i).getWeight()
                            -
                            records.get(i - 1).getWeight();
        }

        if (trendChange < 0) {

            return "Decreasing";

        } else if (trendChange > 0) {

            return "Increasing";

        } else {

            return "Stable";
        }
    }

    /*
     * Calculate percentage progress from the
     * starting weight toward the goal.
     */
    private double calculateGoalProgress(
            double startingWeight,
            double currentWeight,
            double goalWeight
    ) {

        double totalNeeded =
                goalWeight - startingWeight;

        if (totalNeeded == 0) {

            return currentWeight == goalWeight
                    ? 100.0
                    : 0.0;
        }

        double progress =
                ((currentWeight - startingWeight)
                        / totalNeeded)
                        * 100.0;

        /*
         * Keep progress between 0 and 100 percent.
         */
        return Math.max(
                0.0,
                Math.min(
                        100.0,
                        progress
                )
        );
    }

    /*
     * Display a message when there are no saved records.
     */
    private void showNoData() {

        startingWeightDisplay.setText(
                "Starting Weight: No data"
        );

        currentWeightDisplay.setText(
                "Current Weight: No data"
        );

        totalChangeDisplay.setText(
                "Total Change: No data"
        );

        averageChangeDisplay.setText(
                "Average Change Per Entry: No data"
        );

        recentChangeDisplay.setText(
                "Recent Change: No data"
        );

        recentTrendDisplay.setText(
                "Recent Trend: No data"
        );

        goalWeightDisplay.setText(
                "Goal Weight: No data"
        );

        goalProgressDisplay.setText(
                "Goal Progress: No data"
        );

        goalProgressBar.setProgress(0);
    }
}