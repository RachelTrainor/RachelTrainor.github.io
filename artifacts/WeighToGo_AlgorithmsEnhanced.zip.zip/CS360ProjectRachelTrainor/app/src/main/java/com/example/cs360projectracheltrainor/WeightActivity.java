package com.example.cs360projectracheltrainor;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;

public class WeightActivity extends AppCompatActivity {

    private Database db;
    private LinearLayout entryContainer;
    private EditText inputDate, inputWeight, inputGoal, inputPhone;
    private Button addEntry, cancelEdit;
    private Spinner sortSpinner;

    private Long editingId = null;

    // Keep weight limits in one place so they are easy to update.
    private static final double MIN_WEIGHT = 1.0;
    private static final double MAX_WEIGHT = 1500.0;

    // Accept both two-digit and four-digit years.
    private static final DateTimeFormatter[] DATE_FORMATS = {
            DateTimeFormatter.ofPattern("M/d/yyyy"),
            DateTimeFormatter.ofPattern("M/d/yy"),
            DateTimeFormatter.ofPattern("M-d-yyyy"),
            DateTimeFormatter.ofPattern("M-d/yy"),
            DateTimeFormatter.ISO_LOCAL_DATE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_log);

        db = Database.getInstance(this);

        initializeViews();
        setupButtonListeners();
        setupSortSpinner();
        loadWeights();
    }

    /*
     * Connect the activity fields and buttons to the layout.
     */
    private void initializeViews() {
        inputDate = findViewById(R.id.input_date);
        inputWeight = findViewById(R.id.input_weight);
        inputGoal = findViewById(R.id.input_goal_weight);
        inputPhone = findViewById(R.id.input_phone);
        entryContainer = findViewById(R.id.entryContainer);

        addEntry = findViewById(R.id.button_add_entry);
        cancelEdit = findViewById(R.id.button_cancel_edit);
        sortSpinner = findViewById(R.id.sortSpinner);
    }

    /*
     * Set up the sorting options for the weight log.
     */
    private void setupSortSpinner() {

        String[] sortOptions = {
                "Oldest to Newest",
                "Newest to Oldest",
                "Lowest Weight",
                "Highest Weight"
        };

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        sortOptions
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        sortSpinner.setAdapter(adapter);

        sortSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        loadWeights();
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent
                    ) {
                        // Keep the current sorting option.
                    }
                }
        );
    }

    /*
     * Set up the main button actions.
     */
    private void setupButtonListeners() {
        Button setGoal = findViewById(R.id.button_set_goal);
        Button home = findViewById(R.id.buttonHome);

        addEntry.setOnClickListener(v -> handleWeightEntry());
        cancelEdit.setOnClickListener(v -> cancelEditMode());
        setGoal.setOnClickListener(v -> handleGoalWeight());

        home.setOnClickListener(v ->
                startActivity(new Intent(this, HomeActivity.class))
        );
    }

    /*
     * Validate weight information before adding or updating a record.
     */
    private void handleWeightEntry() {
        String date = inputDate.getText().toString().trim();
        String weightStr = inputWeight.getText().toString().trim();
        String phoneNumber = inputPhone.getText().toString().trim();

        if (date.isEmpty()) {
            inputDate.setError("Please enter a date");
            inputDate.requestFocus();
            return;
        }

        if (weightStr.isEmpty()) {
            inputWeight.setError("Please enter your weight");
            inputWeight.requestFocus();
            return;
        }

        try {
            double weight = Double.parseDouble(weightStr);

            if (!isValidWeight(weight)) {
                inputWeight.setError(
                        "Weight must be between 1 and 1500"
                );
                inputWeight.requestFocus();
                return;
            }

            if (editingId != null) {
                updateWeightEntry(weight);
            } else {
                addWeightEntry(date, weight, phoneNumber);
            }

        } catch (NumberFormatException e) {
            inputWeight.setError("Please enter a valid number");
            inputWeight.requestFocus();
        }
    }

    /*
     * Check whether a weight is within the accepted range.
     */
    private boolean isValidWeight(double weight) {
        return weight >= MIN_WEIGHT &&
                weight <= MAX_WEIGHT;
    }

    /*
     * Add a new weight record and check whether
     * the user's goal was reached.
     */
    private void addWeightEntry(
            String date,
            double weight,
            String phoneNumber
    ) {

        long result = db.addWeightEntry(date, weight);

        if (result > 0) {

            Toast.makeText(
                    this,
                    "Entry added",
                    Toast.LENGTH_SHORT
            ).show();

            double goal = db.getGoalWeight();

            if (goal > 0 && weight <= goal) {
                handleGoalReached(phoneNumber);
            }

            clearWeightFields();
            loadWeights();

        } else {

            Toast.makeText(
                    this,
                    "Failed to add entry",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /*
     * Update an existing weight record.
     */
    private void updateWeightEntry(double weight) {

        boolean updated =
                db.updateWeight(editingId, weight);

        if (updated) {

            Toast.makeText(
                    this,
                    "Entry updated",
                    Toast.LENGTH_SHORT
            ).show();

            exitEditMode();
            loadWeights();

        } else {

            Toast.makeText(
                    this,
                    "Update failed",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /*
     * Clear the weight entry fields.
     */
    private void clearWeightFields() {
        inputDate.setText("");
        inputWeight.setText("");
    }

    /*
     * Enter edit mode for a selected record.
     */
    private void enterEditMode(
            long id,
            String date,
            double weight
    ) {

        editingId = id;

        inputDate.setText(date);
        inputWeight.setText(
                String.valueOf(weight)
        );

        addEntry.setText("Update Entry");
        cancelEdit.setVisibility(View.VISIBLE);

        inputWeight.requestFocus();
    }

    /*
     * Leave edit mode.
     */
    private void exitEditMode() {

        editingId = null;

        addEntry.setText("Add");
        cancelEdit.setVisibility(View.GONE);

        clearWeightFields();
    }

    /*
     * Cancel editing without changing the record.
     */
    private void cancelEditMode() {

        exitEditMode();

        Toast.makeText(
                this,
                "Edit canceled",
                Toast.LENGTH_SHORT
        ).show();
    }

    /*
     * Validate and save the goal weight.
     */
    private void handleGoalWeight() {

        String goalStr =
                inputGoal.getText()
                        .toString()
                        .trim();

        if (goalStr.isEmpty()) {

            inputGoal.setError(
                    "Please enter a goal weight"
            );

            inputGoal.requestFocus();
            return;
        }

        try {

            double goalWeight =
                    Double.parseDouble(goalStr);

            if (!isValidWeight(goalWeight)) {

                inputGoal.setError(
                        "Goal weight must be between 1 and 1500"
                );

                inputGoal.requestFocus();
                return;
            }

            db.setGoalWeight(goalWeight);

            Toast.makeText(
                    this,
                    "Goal set: " + goalWeight,
                    Toast.LENGTH_SHORT
            ).show();

            inputGoal.setText("");

        } catch (NumberFormatException e) {

            inputGoal.setError(
                    "Please enter a valid number"
            );

            inputGoal.requestFocus();
        }
    }

    /*
     * Retrieve weight records from the database,
     * store them in an ArrayList, sort them based
     * on the user's selected option, and display them.
     */
    private void loadWeights() {

        entryContainer.removeAllViews();

        ArrayList<WeightRecord> weightRecords =
                new ArrayList<>();

        Cursor cursor = db.getAllWeights();

        if (cursor.moveToFirst()) {

            do {

                long id = cursor.getLong(
                        cursor.getColumnIndexOrThrow(
                                Database.W_ID
                        )
                );

                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                Database.W_DATE
                        )
                );

                double weight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow(
                                Database.W_WEIGHT
                        )
                );

                WeightRecord record =
                        new WeightRecord(
                                id,
                                date,
                                weight
                        );

                weightRecords.add(record);

            } while (cursor.moveToNext());
        }

        cursor.close();

        /*
         * Sort the ArrayList based on the option
         * selected by the user.
         */
        int sortOption =
                sortSpinner.getSelectedItemPosition();

        switch (sortOption) {

            case 1:

                // Newest to oldest.
                weightRecords.sort(
                        Comparator.comparing(
                                (WeightRecord record) ->
                                        parseDate(
                                                record.getDate()
                                        )
                        ).reversed()
                );

                break;

            case 2:

                // Lowest weight to highest weight.
                weightRecords.sort(
                        Comparator.comparingDouble(
                                WeightRecord::getWeight
                        )
                );

                break;

            case 3:

                // Highest weight to lowest weight.
                weightRecords.sort(
                        Comparator.comparingDouble(
                                WeightRecord::getWeight
                        ).reversed()
                );

                break;

            default:

                // Oldest to newest.
                weightRecords.sort(
                        Comparator.comparing(
                                record ->
                                        parseDate(
                                                record.getDate()
                                        )
                        )
                );

                break;
        }

        /*
         * Display the sorted records.
         */
        for (WeightRecord record : weightRecords) {

            createWeightRow(
                    record.getId(),
                    record.getDate(),
                    record.getWeight()
            );
        }
    }

    /*
     * Convert a stored date into a LocalDate
     * so records can be sorted correctly.
     */
    private LocalDate parseDate(String date) {

        for (DateTimeFormatter formatter :
                DATE_FORMATS) {

            try {

                return LocalDate.parse(
                        date,
                        formatter
                );

            } catch (
                    DateTimeParseException ignored
            ) {

                // Try the next supported format.
            }
        }

        /*
         * Invalid dates are placed at the end
         * instead of crashing the application.
         */
        return LocalDate.MAX;
    }

    /*
     * Create the visual row for one weight record.
     */
    private void createWeightRow(
            long id,
            String date,
            double weight
    ) {

        LinearLayout row =
                new LinearLayout(this);

        row.setOrientation(
                LinearLayout.HORIZONTAL
        );

        row.setPadding(
                8,
                8,
                8,
                8
        );

        TextView dateView =
                createRowText(date);

        TextView weightView =
                createRowText(
                        String.valueOf(weight)
                );

        Button editButton =
                createEditButton(
                        id,
                        date,
                        weight
                );

        Button deleteButton =
                createDeleteButton(id);

        row.addView(dateView);
        row.addView(weightView);
        row.addView(editButton);
        row.addView(deleteButton);

        entryContainer.addView(row);
    }

    /*
     * Create consistently formatted text for each record.
     */
    private TextView createRowText(
            String text
    ) {

        TextView textView =
                new TextView(this);

        textView.setText(text);

        textView.setLayoutParams(
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                )
        );

        return textView;
    }

    /*
     * Create the Edit button for a record.
     */
    private Button createEditButton(
            long id,
            String date,
            double weight
    ) {

        Button editButton =
                new Button(this);

        editButton.setText("Edit");

        editButton.setOnClickListener(
                v -> enterEditMode(
                        id,
                        date,
                        weight
                )
        );

        return editButton;
    }

    /*
     * Create the Delete button for a record.
     */
    private Button createDeleteButton(
            long id
    ) {

        Button deleteButton =
                new Button(this);

        deleteButton.setText("Delete");

        deleteButton.setBackgroundTintList(
                getResources()
                        .getColorStateList(
                                android.R.color.holo_red_dark,
                                null
                        )
        );

        deleteButton.setTextColor(
                getResources()
                        .getColor(
                                android.R.color.white,
                                null
                        )
        );

        deleteButton.setOnClickListener(
                v -> confirmDelete(id)
        );

        return deleteButton;
    }

    /*
     * Ask for confirmation before deleting a record.
     */
    private void confirmDelete(long id) {

        new AlertDialog.Builder(this)
                .setTitle(
                        "Delete Entry"
                )
                .setMessage(
                        "Are you sure you want to delete " +
                                "this weight entry?"
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, which) ->
                                deleteWeightEntry(id)
                )
                .setNegativeButton(
                        "Cancel",
                        (dialog, which) ->
                                dialog.dismiss()
                )
                .show();
    }

    /*
     * Delete a record and refresh the weight log.
     */
    private void deleteWeightEntry(
            long id
    ) {

        db.deleteWeight(id);

        if (editingId != null &&
                editingId == id) {

            exitEditMode();
        }

        loadWeights();

        Toast.makeText(
                this,
                "Entry deleted",
                Toast.LENGTH_SHORT
        ).show();
    }

    /*
     * Handle the goal notification process.
     */
    private void handleGoalReached(
            String phoneNumber
    ) {

        if (phoneNumber == null ||
                phoneNumber.isEmpty()) {

            Toast.makeText(
                    this,
                    "Goal reached! Add a phone number " +
                            "to receive an SMS.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) !=
                PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    "Goal reached! SMS permission " +
                            "is not enabled.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        sendGoalSms(phoneNumber);
    }

    /*
     * Send the goal notification SMS.
     */
    private void sendGoalSms(
            String phoneNumber
    ) {

        try {

            SmsManager smsManager =
                    SmsManager.getDefault();

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    "Congratulations! You have " +
                            "reached your goal weight!",
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Goal reached! SMS sent.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Goal reached, but the SMS " +
                            "could not be sent.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}