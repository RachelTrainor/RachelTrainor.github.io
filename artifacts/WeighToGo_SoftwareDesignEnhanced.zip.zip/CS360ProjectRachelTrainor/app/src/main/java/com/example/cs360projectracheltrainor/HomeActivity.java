package com.example.cs360projectracheltrainor;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    // display current and goal weight
    private TextView currentWeightDisplay;
    private TextView goalWeightDisplay;
    private Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home); // connect to layout

        // get instance of database
        db = Database.getInstance(this);

        // connect ui elements to layout
        currentWeightDisplay = findViewById(R.id.currentWeightDisplay);
        goalWeightDisplay = findViewById(R.id.goalWeightDisplay);

        // button for sms permissions screen
        Button buttonPermissions = findViewById(R.id.buttonPermissions);

        //button for weight log screen
        Button buttonWeightLog = findViewById(R.id.buttonWeightLog);

        // logout button
        Button logout = findViewById(R.id.buttonLogout);

        // transition animation for sms screen
        buttonPermissions.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, Activity_sms.class);
            ActivityOptions options = ActivityOptions.makeCustomAnimation(
                    HomeActivity.this,
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
            );
            startActivity(intent, options.toBundle());
        });

        // transition animation for weight log screen
        buttonWeightLog.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, WeightActivity.class);
            ActivityOptions options = ActivityOptions.makeCustomAnimation(
                    HomeActivity.this,
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
            );
            startActivity(intent, options.toBundle());
        });

        // handles logout by navigating to login screen
        logout.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // get lastest values when opened
        double goal = db.getGoalWeight();
        double current = db.getLatestWeight();

        // update ui with current and goal weight
        currentWeightDisplay.setText("Current Weight: " + (current > 0 ? current : "N/A"));
        goalWeightDisplay.setText("Goal Weight: " + (goal > 0 ? goal : "Not Set"));
    }
}