package com.example.cs360projectracheltrainor;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Activity_sms extends AppCompatActivity {

    private static final int REQ_SEND_SMS = 101;

    private ImageView iconStatus;
    private TextView textStatus;
    private Button btnRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms); // connects to layout

        // connects ui elements to layout
        iconStatus = findViewById(R.id.iconSMSStatus);
        textStatus = findViewById(R.id.textSMSStatus);
        btnRequest = findViewById(R.id.buttonRequestSMS);

        // initial status
        updateSmsStatusUI(isSmsGranted());

        // request permission
        btnRequest.setOnClickListener(v -> {
            if (isSmsGranted()) {
                // notify if already granted
                Toast.makeText(this, "SMS permission already granted.", Toast.LENGTH_SHORT).show();
                pulseStatus();
            } else {
                // request permission
                requestSmsPermission();
            }
        });

        // home button
        View homeBtn = findViewById(R.id.buttonHome);
        if (homeBtn != null) {
            homeBtn.setOnClickListener(v -> finish());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateSmsStatusUI(isSmsGranted());
    }

    private boolean isSmsGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    // check if permissions are granted
    private void requestSmsPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            new AlertDialog.Builder(this)
                    .setTitle("Allow SMS notifications?")
                    .setMessage("We use SMS to notify you when you reach your goal weight. You can use the app without this, but you won’t receive goal notifications.")
                    .setPositiveButton("Continue", (d, w) ->
                            ActivityCompat.requestPermissions(this,
                                    new String[]{Manifest.permission.SEND_SMS},
                                    REQ_SEND_SMS))
                    .setNegativeButton("Not now", null)
                    .show();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, REQ_SEND_SMS);
        }
    }

    // results after permission is granted or denied
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_SEND_SMS) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;

            updateSmsStatusUI(granted);

            if (!granted) {
                boolean showRationale =
                        ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS);

                if (!showRationale) {
                    showSettingsDialog();
                } else {
                    Toast.makeText(this, "Permission denied. No SMS notifications.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Permission granted! You’ll receive goal notifications.", Toast.LENGTH_SHORT).show();
                pulseStatus();
            }
        }
    }

    // guide to enable permissions in settings
    private void showSettingsDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Enable SMS in Settings")
                .setMessage("To receive goal notifications, enable SMS permission in App Settings.")
                .setPositiveButton("Open Settings", (d, w) -> openAppSettings())
                .setNegativeButton("Cancel", null)
                .show();
    }

    // open settings
    private void openAppSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.fromParts("package", getPackageName(), null));
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Unable to open settings.", Toast.LENGTH_SHORT).show();
        }
    }

    // update to reflect permission status
    private void updateSmsStatusUI(boolean granted) {
        if (granted) {
            iconStatus.setImageResource(android.R.drawable.presence_online);
            iconStatus.setImageTintList(ContextCompat.getColorStateList(this, android.R.color.holo_green_dark));
            textStatus.setText("SMS permission granted. You’ll receive goal notifications.");
            textStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        } else {
            iconStatus.setImageResource(android.R.drawable.presence_offline);
            iconStatus.setImageTintList(ContextCompat.getColorStateList(this, android.R.color.darker_gray));
            textStatus.setText("SMS permission denied. App works, but no goal notifications.");
            textStatus.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray));
        }
        iconStatus.setAlpha(0f);
        textStatus.setAlpha(0f);
        iconStatus.animate().alpha(1f).setDuration(180).start();
        textStatus.animate().alpha(1f).setDuration(180).start();
    }

    private void pulseStatus() {
        iconStatus.setScaleX(0.9f);
        iconStatus.setScaleY(0.9f);
        iconStatus.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
    }
}