package com.example.cs360projectracheltrainor;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editUsername, editPassword;
    private Button btnLogin, btnRegister;
    private Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);   // connect to layout

        // connect ui elements to layout
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        btnLogin     = findViewById(R.id.buttonLogin);
        btnRegister  = findViewById(R.id.buttonRegister);


        db = Database.getInstance(this);

        btnLogin.setOnClickListener(v -> loginUser());
        btnRegister.setOnClickListener(v -> registerUser());
    }

    // user login
    private void loginUser() {
        String u = editUsername.getText().toString().trim();
        String p = editPassword.getText().toString();

        // makes sure input not empty
        if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
            Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // attempt login
        long id = db.loginUser(u, p);
        if (id > 0) {
            // successful login
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, HomeActivity.class));
            // failed
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    // user registration
    private void registerUser() {
        String u = editUsername.getText().toString().trim();
        String p = editPassword.getText().toString();

        if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
            Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // attempts registration
        boolean ok = db.registerUser(u, p);
        if (ok) {
            //successful
            Toast.makeText(this, "Account created! Please log in.", Toast.LENGTH_SHORT).show();
          // username already in use
        } else {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
        }
    }
}