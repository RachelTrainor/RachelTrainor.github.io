package com.example.cs360projectracheltrainor;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

// database class for managing data
public class Database extends SQLiteOpenHelper {

    private static final String DB_NAME = "weigh_to_go.db";
    private static final int DB_VERSION = 3;

    // username and password table for logging in
    public static final String T_USERS = "users";
    public static final String U_ID = "id";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";

    // weights and dates table
    public static final String T_WEIGHTS = "weights";
    public static final String W_ID = "id";
    public static final String W_DATE = "date";
    public static final String W_WEIGHT = "weight";

    private static volatile Database INSTANCE;

    // singleton to get only one instance of database
    public static Database getInstance(Context ctx) {
        if (INSTANCE == null) {
            synchronized (Database.class) {
                if (INSTANCE == null) {
                    INSTANCE = new Database(ctx.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }

    private Database(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // creates tables when database is created
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                U_USERNAME + " TEXT UNIQUE," +
                U_PASSWORD + " TEXT)");

        db.execSQL("CREATE TABLE " + T_WEIGHTS + " (" +
                W_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                W_DATE + " TEXT," +
                W_WEIGHT + " REAL)");

        // goal weights table with one value
        db.execSQL("CREATE TABLE IF NOT EXISTS goal_weight (weight REAL)");
    }

    // recreates tables
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS goal_weight");
        onCreate(db);
    }


    // registers new user, returns if registration is successful
    public boolean registerUser(String username, String password) {
        try {
            ContentValues cv = new ContentValues();
            cv.put(U_USERNAME, username.trim());
            cv.put(U_PASSWORD, password);
            long id = getWritableDatabase().insertOrThrow(T_USERS, null, cv);
            return id > 0;
        } catch (Exception e) {
            Log.e("Database", "registerUser failed", e);
            return false;
        }
    }

    // attempts login, return if successful or login failed
    public long loginUser(String username, String password) {
        Cursor c = getReadableDatabase().query(
                T_USERS,
                new String[]{U_ID},
                U_USERNAME + "=? AND " + U_PASSWORD + "=?",
                new String[]{username.trim(), password},
                null, null, null
        );
        long id = -1;
        if (c.moveToFirst()) id = c.getLong(0);
        c.close();
        return id;
    }



    // adds a new weight entry with date and weight
    public long addWeightEntry(String date, double weight) {
        ContentValues cv = new ContentValues();
        cv.put(W_DATE, date.trim());
        cv.put(W_WEIGHT, weight);
        return getWritableDatabase().insert(T_WEIGHTS, null, cv);
    }

    // retrieves all weight log entries
    public Cursor getAllWeights() {
        return getReadableDatabase().query(
                T_WEIGHTS,
                new String[]{W_ID, W_DATE, W_WEIGHT},
                null, null, null, null,
                W_ID + " DESC"
        );
    }

    // updates weight entry
    public boolean updateWeight(long id, double newWeight) {
        ContentValues cv = new ContentValues();
        cv.put(W_WEIGHT, newWeight);
        int rows = getWritableDatabase().update(T_WEIGHTS, cv, W_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    // deletes a weight entry
    public boolean deleteWeight(long id) {
        int rows = getWritableDatabase().delete(T_WEIGHTS, W_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }



    // set new goal weight deleted existing
    public void setGoalWeight(double weight) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM goal_weight"); // Keep only one goal value
        ContentValues cv = new ContentValues();
        cv.put("weight", weight);
        db.insert("goal_weight", null, cv);
    }
// gets saved goal weight
    public double getGoalWeight() {
        Cursor c = getReadableDatabase().rawQuery("SELECT weight FROM goal_weight LIMIT 1", null);
        double goal = -1;
        if (c.moveToFirst()) goal = c.getDouble(0);
        c.close();
        return goal;
    }

    // returns most recent weight
    public double getLatestWeight() {
        Cursor c = getReadableDatabase().query(
                T_WEIGHTS,
                new String[]{W_WEIGHT},
                null, null, null, null,
                W_ID + " DESC",
                "1"
        );
        double weight = -1;
        if (c.moveToFirst()) {
            weight = c.getDouble(0);
        }
        c.close();
        return weight;
    }
}