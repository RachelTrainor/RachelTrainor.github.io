package com.example.cs360projectracheltrainor;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class WeightActivity extends AppCompatActivity {

    private Database db;
    private LinearLayout entryContainer;
    private EditText inputDate, inputWeight, inputGoal, inputPhone;
    private Button addEntry, cancelEdit;

    private Long editingId = null;

    // Keep weight limits in one place so they are easy to update later.
    private static final double MIN_WEIGHT = 1.0;
    private static final double MAX_WEIGHT = 1500.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_log);

        db = Database.getInstance(this);

        initializeViews();
        setupButtonListeners();
        loadWeights();
    }

    /*
     * Connect the activity fields and buttons to the layout.
     */
    private void initializeViews() {
        inputDate = findViewById(R.id.input_date);
        inputWeight = findViewById(R.id.input_weight);
        inputGoal = findViewById(R.id.input_goal_weight);
        inputPhone = findViewById(R.id.input_phone);
        entryContainer = findViewById(R.id.entryContainer);

        addEntry = findViewById(R.id.button_add_entry);
        cancelEdit = findViewById(R.id.button_cancel_edit);
    }

    /*
     * Set up the main button actions in one place.
     */
    private void setupButtonListeners() {
        Button setGoal = findViewById(R.id.button_set_goal);
        Button home = findViewById(R.id.buttonHome);

        addEntry.setOnClickListener(v -> handleWeightEntry());
        cancelEdit.setOnClickListener(v -> cancelEditMode());
        setGoal.setOnClickListener(v -> handleGoalWeight());

        home.setOnClickListener(v ->
                startActivity(new Intent(this, HomeActivity.class))
        );
    }

    /*
     * Validate weight information before adding or updating a record.
     */
    private void handleWeightEntry() {
        String date = inputDate.getText().toString().trim();
        String weightStr = inputWeight.getText().toString().trim();
        String phoneNumber = inputPhone.getText().toString().trim();

        if (date.isEmpty()) {
            inputDate.setError("Please enter a date");
            inputDate.requestFocus();
            return;
        }

        if (weightStr.isEmpty()) {
            inputWeight.setError("Please enter your weight");
            inputWeight.requestFocus();
            return;
        }

        try {
            double weight = Double.parseDouble(weightStr);

            if (!isValidWeight(weight)) {
                inputWeight.setError("Weight must be between 1 and 1500");
                inputWeight.requestFocus();
                return;
            }

            if (editingId != null) {
                updateWeightEntry(weight);
            } else {
                addWeightEntry(date, weight, phoneNumber);
            }

        } catch (NumberFormatException e) {
            inputWeight.setError("Please enter a valid number");
            inputWeight.requestFocus();
        }
    }

    /*
     * Reuse the same accepted range for recorded and goal weights.
     */
    private boolean isValidWeight(double weight) {
        return weight >= MIN_WEIGHT && weight <= MAX_WEIGHT;
    }

    /*
     * Add a new weight record and check whether the user's goal was reached.
     */
    private void addWeightEntry(String date, double weight, String phoneNumber) {
        long result = db.addWeightEntry(date, weight);

        if (result > 0) {
            Toast.makeText(
                    this,
                    "Entry added",
                    Toast.LENGTH_SHORT
            ).show();

            double goal = db.getGoalWeight();

            if (goal > 0 && weight <= goal) {
                handleGoalReached(phoneNumber);
            }

            clearWeightFields();
            loadWeights();

        } else {
            Toast.makeText(
                    this,
                    "Failed to add entry",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /*
     * Update an existing weight record and leave edit mode
     * after the update succeeds.
     */
    private void updateWeightEntry(double weight) {
        boolean updated = db.updateWeight(editingId, weight);

        if (updated) {
            Toast.makeText(
                    this,
                    "Entry updated",
                    Toast.LENGTH_SHORT
            ).show();

            exitEditMode();
            loadWeights();

        } else {
            Toast.makeText(
                    this,
                    "Update failed",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /*
     * Clear the date and weight entry fields.
     */
    private void clearWeightFields() {
        inputDate.setText("");
        inputWeight.setText("");
    }

    /*
     * Put the activity into edit mode for the selected record.
     */
    private void enterEditMode(long id, String date, double weight) {
        editingId = id;

        inputDate.setText(date);
        inputWeight.setText(String.valueOf(weight));

        addEntry.setText("Update Entry");
        cancelEdit.setVisibility(View.VISIBLE);

        inputWeight.requestFocus();
    }

    /*
     * Return the activity to its normal Add Entry state.
     */
    private void exitEditMode() {
        editingId = null;

        addEntry.setText("Add");
        cancelEdit.setVisibility(View.GONE);

        clearWeightFields();
    }

    /*
     * Allow the user to leave edit mode without changing the record.
     */
    private void cancelEditMode() {
        exitEditMode();

        Toast.makeText(
                this,
                "Edit canceled",
                Toast.LENGTH_SHORT
        ).show();
    }

    /*
     * Validate and save the user's goal weight.
     */
    private void handleGoalWeight() {
        String goalStr = inputGoal.getText().toString().trim();

        if (goalStr.isEmpty()) {
            inputGoal.setError("Please enter a goal weight");
            inputGoal.requestFocus();
            return;
        }

        try {
            double goalWeight = Double.parseDouble(goalStr);

            if (!isValidWeight(goalWeight)) {
                inputGoal.setError(
                        "Goal weight must be between 1 and 1500"
                );
                inputGoal.requestFocus();
                return;
            }

            db.setGoalWeight(goalWeight);

            Toast.makeText(
                    this,
                    "Goal set: " + goalWeight,
                    Toast.LENGTH_SHORT
            ).show();

            inputGoal.setText("");

        } catch (NumberFormatException e) {
            inputGoal.setError("Please enter a valid number");
            inputGoal.requestFocus();
        }
    }

    /*
     * Retrieve all saved weight records and display them in the log.
     */
    private void loadWeights() {
        entryContainer.removeAllViews();

        Cursor cursor = db.getAllWeights();

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(
                        cursor.getColumnIndexOrThrow(Database.W_ID)
                );

                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow(Database.W_DATE)
                );

                double weight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow(Database.W_WEIGHT)
                );

                createWeightRow(id, date, weight);

            } while (cursor.moveToNext());
        }

        cursor.close();
    }

    /*
     * Create the visual row for one weight record.
     */
    private void createWeightRow(long id, String date, double weight) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(8, 8, 8, 8);

        TextView dateView = createRowText(date);
        TextView weightView = createRowText(String.valueOf(weight));

        Button editButton = createEditButton(id, date, weight);
        Button deleteButton = createDeleteButton(id);

        row.addView(dateView);
        row.addView(weightView);
        row.addView(editButton);
        row.addView(deleteButton);

        entryContainer.addView(row);
    }

    /*
     * Create consistently formatted text for each record.
     */
    private TextView createRowText(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);

        textView.setLayoutParams(
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                )
        );

        return textView;
    }

    /*
     * Create the Edit button for a weight record.
     */
    private Button createEditButton(long id, String date, double weight) {
        Button editButton = new Button(this);
        editButton.setText("Edit");

        editButton.setOnClickListener(v ->
                enterEditMode(id, date, weight)
        );

        return editButton;
    }

    /*
     * Create the Delete button for a weight record.
     */
    private Button createDeleteButton(long id) {
        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");

        deleteButton.setBackgroundTintList(
                getResources().getColorStateList(
                        android.R.color.holo_red_dark,
                        null
                )
        );

        deleteButton.setTextColor(
                getResources().getColor(
                        android.R.color.white,
                        null
                )
        );

        deleteButton.setOnClickListener(v -> confirmDelete(id));

        return deleteButton;
    }

    /*
     * Ask for confirmation before permanently deleting a record.
     */
    private void confirmDelete(long id) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Entry")
                .setMessage(
                        "Are you sure you want to delete this weight entry?"
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> deleteWeightEntry(id)
                )
                .setNegativeButton(
                        "Cancel",
                        (dialog, which) -> dialog.dismiss()
                )
                .show();
    }

    /*
     * Delete the selected record and refresh the displayed list.
     */
    private void deleteWeightEntry(long id) {
        db.deleteWeight(id);

        if (editingId != null && editingId == id) {
            exitEditMode();
        }

        loadWeights();

        Toast.makeText(
                this,
                "Entry deleted",
                Toast.LENGTH_SHORT
        ).show();
    }

    /*
     * Handle the notification process when the user reaches
     * the saved goal weight.
     */
    private void handleGoalReached(String phoneNumber) {

        if (phoneNumber == null || phoneNumber.isEmpty()) {
            Toast.makeText(
                    this,
                    "Goal reached! Add a phone number to receive an SMS.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    "Goal reached! SMS permission is not enabled.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        sendGoalSms(phoneNumber);
    }

    /*
     * Send the SMS after the required information and permission
     * have already been checked.
     */
    private void sendGoalSms(String phoneNumber) {
        try {
            SmsManager smsManager = SmsManager.getDefault();

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    "Congratulations! You have reached your goal weight!",
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Goal reached! SMS sent.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Goal reached, but the SMS could not be sent.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}