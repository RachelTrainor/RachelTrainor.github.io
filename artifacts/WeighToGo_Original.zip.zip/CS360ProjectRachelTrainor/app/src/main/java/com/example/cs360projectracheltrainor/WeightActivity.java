package com.example.cs360projectracheltrainor;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class WeightActivity extends AppCompatActivity {

    private Database db;
    private LinearLayout entryContainer;
    private EditText inputDate, inputWeight, inputGoal, inputPhone;
    private TextView textGoal;
    private double goalWeight = -1;
    private Long editingId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_log); // connects to layout

        db = Database.getInstance(this);

        // links UI components to layout
        inputDate = findViewById(R.id.input_date);
        inputWeight = findViewById(R.id.input_weight);
        inputGoal = findViewById(R.id.input_goal_weight);
        inputPhone = findViewById(R.id.input_phone);
        Button addEntry = findViewById(R.id.button_add_entry);
        Button setGoal = findViewById(R.id.button_set_goal);
        Button home = findViewById(R.id.buttonHome);
        entryContainer = findViewById(R.id.entryContainer);

        // add or update weight entry
        addEntry.setOnClickListener(v -> {
            String date = inputDate.getText().toString().trim();
            String weightStr = inputWeight.getText().toString().trim();
            String phoneNumber = inputPhone.getText().toString().trim();

            if (date.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(this, "Please fill both fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double weight = Double.parseDouble(weightStr);

                if (editingId != null) {
                    boolean updated = db.updateWeight(editingId, weight);
                    if (updated) {
                        Toast.makeText(this, "Entry updated", Toast.LENGTH_SHORT).show();
                        editingId = null;
                        addEntry.setText("Add Entry");
                    } else {
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    long result = db.addWeightEntry(date, weight);
                    if (result > 0) {
                        Toast.makeText(this, "Entry added", Toast.LENGTH_SHORT).show();

                        // Check if goal is reached and send SMS if allowed
                        double goal = db.getGoalWeight();
                        if (goal > 0 && weight <= goal) {
                            sendGoalSms(phoneNumber);
                        }

                    } else {
                        Toast.makeText(this, "Failed to add entry", Toast.LENGTH_SHORT).show();
                    }
                }

                inputDate.setText("");
                inputWeight.setText("");
                loadWeights();

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show();
            }
        });

        // set goal weight
        setGoal.setOnClickListener(v -> {
            String goalStr = inputGoal.getText().toString().trim();
            try {
                goalWeight = Double.parseDouble(goalStr);
                db.setGoalWeight(goalWeight);
                Toast.makeText(this, "Goal set: " + goalWeight, Toast.LENGTH_SHORT).show();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid goal", Toast.LENGTH_SHORT).show();
            }
        });

        // home button
        home.setOnClickListener(v -> {
            startActivity(new Intent(this, HomeActivity.class));
        });

        loadWeights();
    }

    // load entries from database
    private void loadWeights() {
        entryContainer.removeAllViews();
        Cursor cursor = db.getAllWeights();

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(Database.W_ID));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(Database.W_DATE));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(Database.W_WEIGHT));

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(8, 8, 8, 8);

                TextView dateView = new TextView(this);
                dateView.setText(date);
                dateView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

                TextView weightView = new TextView(this);
                weightView.setText(String.valueOf(weight));
                weightView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

                Button editButton = new Button(this);
                editButton.setText("Edit");
                editButton.setOnClickListener(v -> {
                    inputDate.setText(date);
                    inputWeight.setText(String.valueOf(weight));
                    editingId = id;
                    Button addEntry = findViewById(R.id.button_add_entry);
                    addEntry.setText("Update Entry");
                });

                Button deleteButton = new Button(this);
                deleteButton.setText("Delete");
                deleteButton.setBackgroundTintList(getResources().getColorStateList(android.R.color.holo_red_dark, null));
                deleteButton.setTextColor(getResources().getColor(android.R.color.white, null));
                deleteButton.setOnClickListener(v -> {
                    db.deleteWeight(id);
                    loadWeights();
                });

                row.addView(dateView);
                row.addView(weightView);
                row.addView(editButton);
                row.addView(deleteButton);

                entryContainer.addView(row);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    // send SMS when goal weight is reached
    private void sendGoalSms(String phoneNumber) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            if (phoneNumber != null && !phoneNumber.isEmpty()) {
                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNumber, null,
                            "Congratulations! You have reached your goal weight!", null, null);
                    Toast.makeText(this, "SMS sent!", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}